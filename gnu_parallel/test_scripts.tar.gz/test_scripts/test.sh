echo `date && hostname`

